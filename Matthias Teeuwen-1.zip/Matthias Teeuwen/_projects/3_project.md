---
title: Standplaats Wereld
layout: post
redirect: https://standplaatswereld.nl/?s=Matthias+Teeuwen
description: Check out my blogs on Standplaats Wereld, an anthropology weblog
---
