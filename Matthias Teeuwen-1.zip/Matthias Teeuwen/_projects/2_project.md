---
title: Dorothy Gemeenschap
layout: post
redirect: https://dorothygemeenschap.nl
description: An intentional community in the spirit of the Catholic Worker movement
  (website in Dutch)
---
