---
layout: about
profile:
  align: right
  image: profile.png
permalink: "/"
published: true
---

Welcome to my site, this is my constant online presence. I'm an anthropologist specialised in religion and ethics and education. I'm also trained in hermeneutics and I have a longstanding interest in literature and poetry. Currently working on becoming a better teacher.  

I write blogs for `Standplaats Wereld` and I'm involved with some social projects near Amsterdam with my intentional community `Dorothy Gemeenschap`. 

You can contact me by emailing me at [info@mcjteeuwen.nl](mailto:info@mcjteeuwen.nl) or click on one of the profile links below.
